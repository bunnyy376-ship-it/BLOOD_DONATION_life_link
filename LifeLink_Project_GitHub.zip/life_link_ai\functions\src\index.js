"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.onDonationStatusChanged = exports.onBloodRequestCreated = exports.checkEligibility = void 0;
const functions = __importStar(require("firebase-functions"));
const admin = __importStar(require("firebase-admin"));
const geofire_common_1 = require("geofire-common");
admin.initializeApp();
const db = admin.firestore();
// 1. ELIGIBILITY ENGINE (Callable Function)
exports.checkEligibility = functions.https.onCall(async (data, context) => {
    if (!context.auth) {
        throw new functions.https.HttpsError("unauthenticated", "User must be logged in.");
    }
    // Logic:
    // Age: 18–65, Weight: >50kg
    // Hemoglobin: Male >= 13.0, Female >= 12.5
    // Last donation >= 90 days.
    // No chronic diseases, surgeries, etc.
    const { age, weight, hemoglobin, gender, hasChronicDisease, hasRecentSurgery, isOnMedication, lastDonationDate } = data;
    if (age < 18 || age > 65)
        return { status: "Rejected", reason: "Age must be between 18 and 65." };
    if (weight < 50)
        return { status: "Rejected", reason: "Weight must be over 50kg." };
    if (gender === "M" && hemoglobin < 13.0)
        return { status: "Rejected", reason: "Hemoglobin below 13.0 for Male." };
    if (gender === "F" && hemoglobin < 12.5)
        return { status: "Rejected", reason: "Hemoglobin below 12.5 for Female." };
    if (hasChronicDisease || hasRecentSurgery || isOnMedication)
        return { status: "Rejected", reason: "Medical history prevents donation." };
    // Check last donation (needs to be >= 90 days)
    if (lastDonationDate) {
        const lastDonation = new Date(lastDonationDate);
        const daysSince = (Date.now() - lastDonation.getTime()) / (1000 * 3600 * 24);
        if (daysSince < 90) {
            const nextEligible = new Date(lastDonation.getTime() + (90 * 24 * 3600 * 1000));
            return { status: "Temporary", reason: "Wait 90 days between donations.", nextEligibleDate: nextEligible.toISOString() };
        }
    }
    // Update user profile status
    await db.collection("users").doc(context.auth.uid).update({ eligibilityStatus: "Eligible" });
    return { status: "Eligible", reason: "Passed all conditions" };
});
// 2. REAL-TIME MATCHING ENGINE (Firestore Trigger)
exports.onBloodRequestCreated = functions.firestore
    .document("requests/{requestId}")
    .onCreate(async (snap, context) => {
    const requestData = snap.data();
    const requestId = context.params.requestId;
    const center = [requestData.location.latitude, requestData.location.longitude];
    const radiusInM = 5000; // start with 5km
    const bounds = (0, geofire_common_1.geohashQueryBounds)(center, radiusInM);
    const promises = [];
    // Geohash bounding box query
    for (const b of bounds) {
        const q = db.collection("users")
            .where("role", "==", "DONOR")
            .where("eligibilityStatus", "==", "Eligible")
            .where("bloodGroup", "==", requestData.bloodGroup)
            .orderBy("geohash")
            .startAt(b[0])
            .endAt(b[1]);
        promises.push(q.get());
    }
    const snapshots = await Promise.all(promises);
    const matchingDonors = [];
    for (const snap of snapshots) {
        for (const doc of snap.docs) {
            const lat = doc.data().location.latitude;
            const lng = doc.data().location.longitude;
            // Check actual distance using Haversine
            const distanceInKm = (0, geofire_common_1.distanceBetween)([lat, lng], center);
            const distanceInM = distanceInKm * 1000;
            if (distanceInM <= radiusInM) {
                matchingDonors.push({
                    donorId: doc.id,
                    fcmToken: doc.data().fcmToken,
                    distance: distanceInKm,
                    lastActive: doc.data().lastActive
                });
            }
        }
    }
    // Sort by distance ascending and lastActive descending (simple heuristic)
    matchingDonors.sort((a, b) => a.distance - b.distance);
    // Limit matches to top 10 for performance and reliability
    const topDonors = matchingDonors.slice(0, 10);
    const tokens = [];
    for (const donor of topDonors) {
        // Write match to /matches
        await db.collection("matches").doc(`${requestId}_${donor.donorId}`).set({
            requestId,
            donorId: donor.donorId,
            distance: donor.distance,
            status: "PENDING",
            matchedAt: admin.firestore.FieldValue.serverTimestamp()
        });
        if (donor.fcmToken)
            tokens.push(donor.fcmToken);
    }
    // Trigger notifications
    if (tokens.length > 0) {
        const payload = {
            notification: {
                title: `Urgent Blood Request: ${requestData.bloodGroup}`,
                body: `A patient approx ${topDonors[0].distance.toFixed(1)}km away needs your blood immediately.`,
            },
            data: { requestId, click_action: "FLUTTER_NOTIFICATION_CLICK" }
        };
        await admin.messaging().sendToDevice(tokens, payload);
    }
    // Set request status to MATCHED 
    await snap.ref.update({ status: topDonors.length > 0 ? "MATCHED" : "NO_MATCH" });
});
// 3. GAMIFICATION ENGINE (Trigger on donation complete)
exports.onDonationStatusChanged = functions.firestore
    .document("donations/{donationId}")
    .onUpdate(async (change, context) => {
    const newData = change.after.data();
    const prevData = change.before.data();
    if (newData.status === "COMPLETED" && prevData.status !== "COMPLETED") {
        const donorId = newData.donorId;
        const userRef = db.collection("users").doc(donorId);
        await db.runTransaction(async (t) => {
            const doc = await t.get(userRef);
            const currentPoints = doc.data()?.points || 0;
            const newPoints = currentPoints + 100; // 100 points per donation
            let badge = "Newbie";
            if (newPoints >= 1000)
                badge = "Master";
            else if (newPoints >= 500)
                badge = "Lifesaver";
            else if (newPoints >= 100)
                badge = "Helper";
            t.update(userRef, { points: newPoints, badge: badge, lastDonationDate: admin.firestore.FieldValue.serverTimestamp() });
        });
    }
});
//# sourceMappingURL=index.js.map