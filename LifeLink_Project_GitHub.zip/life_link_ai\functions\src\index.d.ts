import * as functions from "firebase-functions";
export declare const checkEligibility: functions.https.CallableFunction<any, Promise<{
    status: string;
    reason: string;
    nextEligibleDate?: never;
} | {
    status: string;
    reason: string;
    nextEligibleDate: string;
}>, unknown>;
export declare const onBloodRequestCreated: any;
export declare const onDonationStatusChanged: any;
//# sourceMappingURL=index.d.ts.map