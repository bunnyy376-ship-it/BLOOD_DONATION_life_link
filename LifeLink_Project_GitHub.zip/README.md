# Life Link AI & Blood Donation Bundle

This repository contains a collection of projects for the Life Link AI platform and blood donation management.

## Projects Included

### 1. Life Link AI (`/life_link_ai`)
A Flutter-based application designed to connect blood donors with those in need using AI-driven matching and eligibility checks.

**Technologies:**
- Flutter / Dart
- Firebase (Functions, Firestore, Auth)
- AI eligibility engine

### 2. Blood Donation Project (`/blood_donation`)
A Python-based utility project for managing donor data and blood requests.

**Technologies:**
- Python
- SQLite (donors.db)

---

## How to Get Started

1. **Life Link AI**:
   - Navigate to `life_link_ai/`.
   - Run `flutter pub get` to install dependencies.
   - Configure your Firebase environment.

2. **Blood Donation**:
   - Navigate to `blood_donation/`.
   - Run `python redplus.py` to start the utility.

## GitHub Ready
This bundle has been cleaned of build artifacts (`build/`, `node_modules/`, `.dart_tool/`) and includes a comprehensive `.gitignore`.
