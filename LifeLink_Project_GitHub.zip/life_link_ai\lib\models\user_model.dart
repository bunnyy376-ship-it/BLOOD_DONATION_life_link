import 'package:cloud_firestore/cloud_firestore.dart';

class UserModel {
  final String uid;
  final String name;
  final String email;
  final String phone;
  final String bloodGroup;
  final GeoPoint location;
  final String geohash;
  final String role; // DONOR, RECIPIENT, HOSPITAL
  final Map<String, dynamic> healthData;
  final DateTime? lastDonationDate;
  final String eligibilityStatus; // Eligible, Temporary, Rejected
  final int points;
  final String badge;
  final String fcmToken;

  UserModel({
    required this.uid,
    required this.name,
    required this.email,
    required this.phone,
    required this.bloodGroup,
    required this.location,
    required this.geohash,
    required this.role,
    required this.healthData,
    this.lastDonationDate,
    required this.eligibilityStatus,
    required this.points,
    required this.badge,
    required this.fcmToken,
  });

  factory UserModel.fromMap(Map<String, dynamic> data) {
    return UserModel(
      uid: data['uid'] ?? '',
      name: data['name'] ?? '',
      email: data['email'] ?? '',
      phone: data['phone'] ?? '',
      bloodGroup: data['bloodGroup'] ?? '',
      location: data['location'] as GeoPoint,
      geohash: data['geohash'] ?? '',
      role: data['role'] ?? 'DONOR',
      healthData: data['healthData'] ?? {},
      lastDonationDate: data['lastDonationDate'] != null ? (data['lastDonationDate'] as Timestamp).toDate() : null,
      eligibilityStatus: data['eligibilityStatus'] ?? 'Rejected',
      points: data['points'] ?? 0,
      badge: data['badge'] ?? 'Newbie',
      fcmToken: data['fcmToken'] ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'name': name,
      'email': email,
      'phone': phone,
      'bloodGroup': bloodGroup,
      'location': location,
      'geohash': geohash,
      'role': role,
      'healthData': healthData,
      'lastDonationDate': lastDonationDate,
      'eligibilityStatus': eligibilityStatus,
      'points': points,
      'badge': badge,
      'fcmToken': fcmToken,
    };
  }
}
