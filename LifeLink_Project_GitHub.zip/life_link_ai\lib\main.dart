import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:google_fonts/google_fonts.dart';

// Screens
// Note: These would usually be in separate files. Simplified for this codebase structure demo.
import 'core/theme/app_theme.dart';
import 'ui/auth/login_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Call Firebase.initializeApp() usually with DefaultFirebaseOptions
  // await Firebase.initializeApp();
  runApp(const LifeLinkApp());
}

class LifeLinkApp extends StatelessWidget {
  const LifeLinkApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Life-Link AI',
      theme: AppTheme.medicalRedTheme,
      home: const LoginScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}
