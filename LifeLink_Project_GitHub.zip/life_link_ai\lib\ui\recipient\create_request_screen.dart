import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';

class CreateRequestScreen extends StatefulWidget {
  const CreateRequestScreen({super.key});

  @override
  State<CreateRequestScreen> createState() => _CreateRequestScreenState();
}

class _CreateRequestScreenState extends State<CreateRequestScreen> {
  String _selectedBloodGroup = 'O+';
  String _selectedUrgency = 'Normal';
  int _units = 1;
  bool _isLoading = false;

  void _submitRequest() async {
    setState(() => _isLoading = true);
    // Simulate Firestore write request
    await Future.delayed(const Duration(seconds: 1));
    setState(() => _isLoading = false);
    
    // Show success dialog
    if(mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Request created! Finding nearest donors...')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('New Blood Request', style: TextStyle(color: Colors.white)),
        backgroundColor: AppTheme.primaryRed,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('Patient Details', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: _selectedBloodGroup,
              decoration: const InputDecoration(labelText: 'Blood Group'),
              items: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
                  .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                  .toList(),
              onChanged: (val) => setState(() => _selectedBloodGroup = val!),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: Text('Units Required: $_units', style: const TextStyle(fontSize: 16)),
                ),
                IconButton(
                  icon: const Icon(Icons.remove_circle_outline, color: AppTheme.primaryRed),
                  onPressed: () {
                    if (_units > 1) setState(() => _units--);
                  },
                ),
                IconButton(
                  icon: const Icon(Icons.add_circle),
                  color: AppTheme.primaryRed,
                  onPressed: () => setState(() => _units++),
                ),
              ],
            ),
            const SizedBox(height: 24),
            const Text('Urgency Level', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: _selectedUrgency,
              decoration: const InputDecoration(labelText: 'Urgency'),
              items: ['Normal', 'Urgent', 'Critical']
                  .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                  .toList(),
              onChanged: (val) => setState(() => _selectedUrgency = val!),
            ),
            const SizedBox(height: 48),
            ElevatedButton(
              onPressed: _isLoading ? null : _submitRequest,
              child: _isLoading
                    ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                    : const Text('SUBMIT REQUEST'),
            ),
          ],
        ),
      ),
    );
  }
}
